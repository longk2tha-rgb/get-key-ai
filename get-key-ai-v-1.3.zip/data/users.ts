import type { User } from './types';

export const USERS: User[] = [
  {
    id: 1,
    name: 'MA VĂN LONG',
    code: 'KDJSHYW537',
    expiryDate: '22/10/2025'
  },
  {
    id: 2,
    name: 'VÀNG GIA NGUYÊN',
    code: 'LAT4637DGT',
    expiryDate: '25/10/2025'
  },
  {
    id: 3,
    name: 'TÔ KHÁNH LINH',
    code: 'KDGTW425UY',
    expiryDate: '25/10/2025'
  },
  {
    id: 4,
    name: 'PHẠM MINH NGỌC',
    code: 'KSLOWT53879',
    expiryDate: '25/10/2025'
  },
  {
    id: 5,
    name: 'PHÀN THỊ LAN',
    code: 'KKSHDGT435',
    expiryDate: '25/10/2025'
  },
  {
    id: 6,
    name: 'NGUYỄN THÙY DIỆP',
    code: 'GSTTER3409',
    expiryDate: '25/10/2025'
  },
  {
    id: 7,
    name: 'MÃ PHƯƠNG THÚY',
    code: 'JSFDGT6300',
    expiryDate: '25/10/2025'
  },
  {
    id: 8,
    name: 'NGUYỄN THỊ HUYỀN DIỆU',
    code: 'KKSFERT345',
    expiryDate: '25/10/2025'
  },
  {
    id: 9,
    name: 'BÀN THỊ THU HUYỀN',
    code: 'KSLOETR342',
    expiryDate: '25/10/2025'
  },
  {
    id: 10,
    name: 'FREETRAINGHIEM',
    code: 'FREE1234',
    expiryDate: '30/10/2025'
  }
];