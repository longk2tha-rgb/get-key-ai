import React, { useState } from 'react';

interface PurchaseModalProps {
  onClose: () => void;
}

const DetailItem: React.FC<{ label: string; value: string; highlight?: boolean }> = ({ label, value, highlight = false }) => (
    <div className="flex justify-between items-center py-3 border-b border-slate-700 last:border-b-0">
        <span className="text-slate-400">{label}</span>
        <span className={`font-semibold text-right ${highlight ? 'text-blue-400' : 'text-white'}`}>{value}</span>
    </div>
);

const PurchaseModal: React.FC<PurchaseModalProps> = ({ onClose }) => {
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'success'>('idle');

  const handlePaymentConfirmation = () => {
    setPaymentStatus('success');
    setTimeout(() => {
        onClose();
    }, 2500); // Auto-close after success message is shown
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in" onClick={onClose}>
      <div 
        className="relative bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl shadow-blue-500/20 w-full max-w-lg mx-auto p-6 md:p-8 transform transition-all duration-300 animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>

        <h2 className="text-2xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-2">
          THANH TOÁN
        </h2>
        <p className="text-slate-300 text-center mb-6">
            Vui lòng quét mã bên dưới để hoàn tất thanh toán của bạn!
        </p>
        
        <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8">
            <div className="w-48 h-48 rounded-lg flex-shrink-0 overflow-hidden">
              <iframe
                loading="lazy"
                className="w-full h-full border-0"
                title="Thông tin thanh toán"
                src="https://www.canva.com/design/DAG2wB2lqVQ/CZuYwMy9shMakYsc4T7U4A/view?embed"
                allowFullScreen>
              </iframe>
            </div>
            <div className="w-full">
                <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
                    <DetailItem label="Ngân hàng" value="SHB Hà Nội - Sài Gòn" />
                    <DetailItem label="STK" value="4444011607" />
                    <DetailItem label="Chủ tài khoản" value="MA VAN LONG" />
                    <DetailItem label="Số tiền" value="15.000 VNĐ" highlight />
                    <DetailItem label="Hạn sử dụng" value="7 ngày" />
                </div>
            </div>
        </div>

        <div className="mt-6">
          {paymentStatus === 'idle' ? (
              <button
                  onClick={handlePaymentConfirmation}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 transform hover:scale-105"
              >
                  Đã thanh toán
              </button>
          ) : (
              <div className="text-center p-3 bg-green-900/50 rounded-lg text-green-300 animate-fade-in">
                  <p className="font-semibold">Thanh toán thành công, hệ thống đang kiểm tra.</p>
                  <p className="text-sm text-slate-400">Tự động quay lại sau giây lát...</p>
              </div>
          )}
        </div>
        
        <div className="mt-6 bg-yellow-900/30 border border-yellow-700 text-yellow-300 p-4 rounded-lg text-center">
            <p className="font-bold text-lg">LƯU Ý QUAN TRỌNG</p>
            <p className="text-sm mt-2">
              Vui lòng nhập <strong className="text-white">Họ và tên + Mã Code bạn mong muốn</strong> (10 ký tự cả số và chữ) vào Nội dung Chuyển khoản để hệ thống kích hoạt mã cho bạn.
            </p>
             <p className="text-xs text-slate-400 mt-2">
                Nếu không đúng mã sẽ không được kích hoạt. Mã sẽ được kích hoạt chậm nhất 24h. Vui lòng LH Zalo <a href="tel:0342733640" className="font-semibold text-blue-400 hover:underline">0342733640</a> nếu gặp vấn đề kĩ thuật.
            </p>
        </div>

      </div>
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scale-in {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
        .animate-scale-in { animation: scale-in 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default PurchaseModal;