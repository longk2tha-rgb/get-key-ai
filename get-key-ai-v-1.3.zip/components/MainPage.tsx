import React, { useState, useEffect, useRef } from 'react';
import type { User, Service } from '../data/types';
import { services } from '../data/services';

// --- ICONS ---

const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
    <circle cx="12" cy="7" r="4"></circle>
  </svg>
);

const LogoutIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
    <polyline points="16 17 21 12 16 7"></polyline>
    <line x1="21" y1="12" x2="9" y2="12"></line>
  </svg>
);

const ArrowRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <line x1="5" y1="12" x2="19" y2="12"></line>
    <polyline points="12 5 19 12 12 19"></polyline>
  </svg>
);

const VideoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <polygon points="23 7 16 12 23 17 23 7"></polygon>
        <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
    </svg>
);


// --- COMPONENTS ---

interface MainPageProps {
  user: User;
  onLogout: () => void;
}

interface ServiceCardProps { 
    service: Service; 
    onSelect: () => void; 
    isActivated: boolean 
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, onSelect, isActivated }) => {
  const isAvailable = service.status === 'available';
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied'>('idle');

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!service.keyData) return;
    
    navigator.clipboard.writeText(service.keyData).then(() => {
        setCopyStatus('copied');
        setTimeout(() => setCopyStatus('idle'), 2000);
    }).catch(err => {
        console.error("Failed to copy key:", err);
    });
  };
  
  const cardClasses = `relative group p-6 rounded-2xl shadow-lg border border-slate-700/50 transform transition-all duration-300 flex flex-col justify-between ${
    isAvailable && !isActivated
      ? 'cursor-pointer bg-slate-800 hover:bg-slate-700/50 hover:-translate-y-2'
      : isAvailable && isActivated
      ? 'cursor-default bg-slate-800'
      : 'bg-slate-800/50 cursor-not-allowed opacity-60'
  }`;
  
  return (
    <div
      onClick={isAvailable && !isActivated ? onSelect : undefined}
      className={cardClasses}
      style={{ minHeight: '140px' }}
    >
      <div className={`absolute -top-px -left-px -right-px h-1.5 bg-gradient-to-r ${service.gradient} rounded-t-2xl group-hover:opacity-100 ${isAvailable ? 'opacity-80' : 'opacity-30'} transition-opacity duration-300`}></div>
      
      <div>
        {!isAvailable && (
          <span className="absolute top-4 right-4 bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-1 rounded-full">
            Sắp ra mắt
          </span>
        )}
        <h3 className="text-xl font-bold text-white pr-16">{service.name}</h3>
      </div>
      
      <div className="mt-4">
        {isAvailable ? (
          isActivated ? (
            <div className="flex flex-col items-start gap-2">
              <p className="text-sm font-semibold text-green-400">Lấy key thành công</p>
              <button
                onClick={handleCopy}
                className="w-full text-sm font-semibold py-2 px-3 rounded-md transition-colors bg-blue-600 text-white hover:bg-blue-500 disabled:bg-slate-600"
              >
                {copyStatus === 'copied' ? 'Đã sao chép!' : 'Sao chép Key'}
              </button>
            </div>
          ) : (
            <div className="font-semibold flex items-center text-blue-400 group-hover:text-blue-300 transition-colors">
              Lấy Key
              <ArrowRightIcon className="w-5 h-5 ml-2 transform transition-transform duration-300 group-hover:translate-x-1" />
            </div>
          )
        ) : (
          <div></div> // Placeholder
        )}
      </div>
    </div>
  );
};

const MainPage: React.FC<MainPageProps> = ({ user, onLogout }) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [activatedServices, setActivatedServices] = useState<Set<string>>(new Set());
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleActivateService = (serviceName: string) => {
    setActivatedServices(prev => new Set(prev).add(serviceName));
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950">
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 shadow-lg p-4 flex justify-between items-center z-20 flex-shrink-0">
        <div className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
          GET KEY AI
        </div>
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center space-x-2 p-2 rounded-full bg-slate-800 hover:bg-slate-700 transition"
            aria-haspopup="true"
            aria-expanded={isProfileOpen}
          >
            <UserIcon className="w-6 h-6 text-slate-300" />
            <span className="hidden md:block text-slate-300 font-medium">{user.name.split(' ').pop()}</span>
          </button>
          
          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-72 bg-slate-800 border border-slate-700 rounded-lg shadow-2xl origin-top-right transform transition-all duration-200 ease-out scale-95 opacity-0 animate-scale-in">
              <div className="p-4 border-b border-slate-700">
                <p className="font-bold text-white truncate">{user.name}</p>
                <p className="text-sm text-slate-400">Trang cá nhân</p>
              </div>
              <div className="p-4 space-y-3 text-sm">
                <div>
                  <p className="text-slate-500">Mã code</p>
                  <p className="text-slate-200 font-mono bg-slate-900 p-2 rounded">{user.code}</p>
                </div>
                <div>
                  <p className="text-slate-500">Ngày hết hạn</p>
                  <p className="text-slate-200">{user.expiryDate}</p>
                </div>
              </div>
              <div className="p-2">
                <button
                  onClick={onLogout}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-2 text-sm text-red-400 rounded-md hover:bg-red-900/50 transition-colors"
                >
                  <LogoutIcon className="w-4 h-4" />
                  <span>Đăng xuất</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </header>
      
      <main className="flex-grow p-4 md:p-8 overflow-y-auto">
          <div className="max-w-7xl mx-auto mb-6">
            <a 
                href="https://drive.google.com/file/d/1qSCc94KRNgOhhPv3CeL2t8WqJWQ-15sz/view?usp=sharing" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-medium text-blue-400 hover:text-blue-300 hover:underline transition-colors duration-300 group"
            >
                <VideoIcon className="w-5 h-5 transition-transform group-hover:scale-110" />
                <span>Video HD Sử dụng (chỉ dùng trên laptop)</span>
            </a>
          </div>
          <div className="text-center mb-8 md:mb-12 max-w-2xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-100">
                  Chào mừng trở lại, {user.name.split(' ').slice(0, 2).join(' ')}!
              </h2>
              <p className="mt-4 text-slate-400">
                  Chọn một trong các dịch vụ bên dưới để bắt đầu hành trình của bạn.
              </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-7xl mx-auto">
              {services.map((service) => (
                  <ServiceCard 
                    key={service.name} 
                    service={service} 
                    onSelect={() => handleActivateService(service.name)}
                    isActivated={activatedServices.has(service.name)}
                  />
              ))}
          </div>
      </main>

      <style>{`
        @keyframes scale-in {
          from { opacity: 0; transform: scale(0.95) translateY(-10px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .animate-scale-in {
          transform-origin: top right;
          animation: scale-in 0.1s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default MainPage;